import React from "react";
function Note(){
  return(
    <div>
      <h1>javascript and react.js<h1>
        <p>this was good</p>
        </div>
 ) ;
 }
 
 





  
