import React from "react";

function HEADER(){
  return(
    <header>
<h1>ShapeShapeAI</h1>
      </header>
  );
}